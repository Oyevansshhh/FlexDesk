import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity, Users, Wallet, CalendarCheck, LayoutDashboard, LogOut,
  Plus, Search, Dumbbell, Menu, X, RefreshCw, AlertCircle, CheckCircle2,
  TrendingUp, ArrowUpRight, UserPlus, ChevronRight, Clock, Sparkles,
  Bell, CreditCard, ClipboardCheck, Settings, Trash2, Edit3
} from 'lucide-react';
import { supabase } from './supabase';

const money = n => new Intl.NumberFormat('en-IN', {
  style: 'currency', currency: 'INR', maximumFractionDigits: 0
}).format(Number(n || 0));

const today = new Date().toISOString().slice(0, 10);

export default function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [gymName, setGymName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [profile, setProfile] = useState(null);
  const [gym, setGym] = useState(null);
  const [members, setMembers] = useState([]);
  const [payments, setPayments] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [plans, setPlans] = useState([]);
  const [tab, setTab] = useState('Dashboard');
  const [search, setSearch] = useState('');
  const [showMember, setShowMember] = useState(false);
  const [memberForm, setMemberForm] = useState({
    full_name: '', phone: '', email: '', plan_id: '',
    membership_start: today, membership_end: ''
  });
  const [mobileNav, setMobileNav] = useState(false);
  const [showPlan, setShowPlan] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [planForm, setPlanForm] = useState({
    name: '', price: '', duration_days: '30'
  });

  useEffect(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session?.user) loadData();
  }, [session]);

  async function authSubmit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setNotice('');
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: fullName, gym_name: gymName } }
        });
        if (error) throw error;
        if (!data.session) {
          setNotice('Account created. Check your email to confirm your account, then log in.');
        } else {
          setNotice('Account created successfully.');
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (e) {
      setError(e.message || 'Something went wrong.');
    } finally {
      setBusy(false);
    }
  }

  async function loadData() {
    if (!session?.user) return;
    setBusy(true);
    setError('');
    try {
      const uid = session.user.id;
      const { data: p, error: pe } = await supabase
        .from('profiles').select('*').eq('id', uid).single();
      if (pe) throw pe;
      setProfile(p);

      const { data: g, error: ge } = await supabase
        .from('gyms').select('*').eq('id', p.gym_id).single();
      if (ge) throw ge;
      setGym(g);

      const results = await Promise.all([
        supabase.from('members').select('*').eq('gym_id', p.gym_id).order('created_at', { ascending: false }),
        supabase.from('payments').select('*').eq('gym_id', p.gym_id).order('payment_date', { ascending: false }),
        supabase.from('attendance').select('*').eq('gym_id', p.gym_id).eq('attendance_date', today),
        supabase.from('membership_plans').select('*').eq('gym_id', p.gym_id).order('created_at')
      ]);
      const firstError = results.find(r => r.error)?.error;
      if (firstError) throw firstError;
      setMembers(results[0].data || []);
      setPayments(results[1].data || []);
      setAttendance(results[2].data || []);
      setPlans(results[3].data || []);
    } catch (e) {
      setError(e.message || 'Could not load gym data.');
    } finally {
      setBusy(false);
    }
  }

  async function savePlan(e) {
    e.preventDefault();
    setError('');
    setNotice('');
    if (!profile?.gym_id) return setError('Gym profile is not ready.');
    if (!planForm.name.trim() || Number(planForm.price) <= 0 || Number(planForm.duration_days) <= 0) {
      return setError('Please enter valid plan details.');
    }
    setBusy(true);
    try {
      const payload = {
        name: planForm.name.trim(),
        price: Number(planForm.price),
        duration_days: Number(planForm.duration_days)
      };
      const result = editingPlan
        ? await supabase.from('membership_plans').update(payload)
            .eq('id', editingPlan.id).eq('gym_id', profile.gym_id)
        : await supabase.from('membership_plans').insert({ ...payload, gym_id: profile.gym_id });
      if (result.error) throw result.error;

      setShowPlan(false);
      setEditingPlan(null);
      setPlanForm({ name: '', price: '', duration_days: '30' });
      setNotice(editingPlan ? 'Plan updated successfully.' : 'Plan added successfully.');
      await loadData();
    } catch (e) {
      setError(e.message || 'Could not save plan.');
    } finally {
      setBusy(false);
    }
  }

  async function deletePlan(plan) {
    if (!window.confirm(`Delete ${plan.name}?`)) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const { error } = await supabase.from('membership_plans')
        .delete().eq('id', plan.id).eq('gym_id', profile.gym_id);
      if (error) throw error;
      setNotice('Plan deleted successfully.');
      await loadData();
    } catch (e) {
      setError(e.message || 'Could not delete plan.');
    } finally {
      setBusy(false);
    }
  }

  async function addMember(e) {
    e.preventDefault();
    setError('');
    setNotice('');
    if (!profile?.gym_id) return setError('Gym profile is not ready. Refresh and try again.');
    setBusy(true);
    try {
      const payload = {
        gym_id: profile.gym_id,
        full_name: memberForm.full_name.trim(),
        phone: memberForm.phone.trim() || null,
        email: memberForm.email.trim() || null,
        plan_id: memberForm.plan_id || null,
        plan_price: plans.find(p => p.id === memberForm.plan_id)?.price ?? null,
        membership_start: memberForm.membership_start || null,
        membership_end: memberForm.membership_end || null,
        created_by: session.user.id
      };
      const { error } = await supabase.from('members').insert(payload);
      if (error) throw error;
      setShowMember(false);
      setMemberForm({
        full_name: '', phone: '', email: '', plan_id: '',
        membership_start: today, membership_end: ''
      });
      setNotice('Member added successfully.');
      await loadData();
    } catch (e) {
      setError(e.message || 'Could not add member.');
    } finally {
      setBusy(false);
    }
  }

  async function deleteMember(id) {
    if (!window.confirm('Delete this member? Related payment or attendance records may prevent deletion.')) return;
    setBusy(true);
    setError('');
    try {
      const { error } = await supabase.from('members').delete().eq('id', id);
      if (error) throw error;
      setNotice('Member deleted.');
      await loadData();
    } catch (e) {
      setError(e.message || 'Could not delete member.');
    } finally {
      setBusy(false);
    }
  }

  async function markAttendance(memberId, status = 'present') {
    setError('');
    setNotice('');
    const { error } = await supabase.from('attendance').upsert(
      { gym_id: profile.gym_id, member_id: memberId, attendance_date: today, status },
      { onConflict: 'gym_id,member_id,attendance_date' }
    );
    if (error) setError(error.message);
    else {
      setNotice('Attendance updated.');
      await loadData();
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    setProfile(null);
    setGym(null);
  }

  const activeMembers = members.filter(m =>
    m.status === 'active' && (!m.membership_end || m.membership_end >= today)
  ).length;
  const month = today.slice(0, 7);
  const monthlyRevenue = payments
    .filter(p => p.status === 'paid' && (p.payment_date || '').startsWith(month))
    .reduce((s, p) => s + Number(p.amount || 0), 0);
  const filteredMembers = useMemo(() =>
    members.filter(m =>
      `${m.full_name} ${m.phone || ''} ${m.email || ''}`
        .toLowerCase().includes(search.toLowerCase())
    ), [members, search]);

  const revenueChart = useMemo(() => Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const amount = payments
      .filter(p => p.status === 'paid' && p.payment_date === key)
      .reduce((sum, p) => sum + Number(p.amount || 0), 0);
    return { day: date.toLocaleDateString('en-IN', { weekday: 'short' }), amount };
  }), [payments]);

  const maxRevenue = Math.max(1, ...revenueChart.map(d => d.amount));

  if (!supabase) return <SetupScreen />;
  if (loading) return <div className="center-screen"><div className="loader" /><p>Loading FlexDesk…</p></div>;
  if (!session) return <AuthScreen {...{
    mode, setMode, email, setEmail, password, setPassword, fullName, setFullName,
    gymName, setGymName, authSubmit, busy, error, notice
  }} />;

  const nav = [
    ['Dashboard', LayoutDashboard],
    ['Members', Users],
    ['Payments', Wallet],
    ['Attendance', CalendarCheck],
    ['Plans', Activity]
  ];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Dumbbell size={22} /></div>
          <div><b>FLEXDESK</b><small>GYM MANAGEMENT</small></div>
          <button className="mobile-close" onClick={() => setMobileNav(false)}><X /></button>
        </div>

        <div className="gym-chip">
          <span className="online-dot" />
          <div><b>{gym?.name || 'Your Gym'}</b><small>{profile?.role || 'gym account'}</small></div>
          <span className="gym-chip-icon"><Dumbbell size={16}/></span>
        </div>

        <div className="nav-label">MAIN MENU</div>
        {nav.map(([label, Icon]) => (
          <button key={label}
            className={`nav-item ${tab === label ? 'active' : ''}`}
            onClick={() => { setTab(label); setMobileNav(false); setShowMember(false); setShowPlan(false); }}>
            <Icon size={18} />{label}
            {tab === label && <span className="nav-active-dot"/>}
          </button>
        ))}

        <div className="sidebar-bottom">
          <div className="sidebar-promo">
            <div className="promo-icon"><Sparkles size={17}/></div>
            <b>Train smarter.</b>
            <span>Your gym, one simple workspace.</span>
          </div>
          <button className="nav-item logout" onClick={signOut}><LogOut size={18}/> Sign out</button>
          <div className="byline">POWERED BY <b>VANSH ✦</b></div>
        </div>
      </aside>

      {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)} />}

      <main className="main-area">
        <header className="topbar">
          <button className="menu-btn" onClick={() => setMobileNav(true)}><Menu /></button>
          <div className="topbar-title">
            <span className="eyebrow">FLEXDESK / WORKSPACE</span>
            <h1>{tab}</h1>
          </div>
          <div className="top-actions">
            <span className="today-pill">{new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
            <button className="icon-btn" onClick={loadData} title="Refresh"><RefreshCw size={17}/></button>
            <button className="icon-btn notification-btn" title="Notifications"><Bell size={17}/></button>
            <div className="avatar">{(profile?.full_name || session.user.email || 'V').slice(0, 1).toUpperCase()}</div>
          </div>
        </header>

        {error && <div className="alert error"><AlertCircle size={18}/>{error}<button onClick={() => setError('')}>×</button></div>}
        {notice && <div className="alert success"><CheckCircle2 size={18}/>{notice}<button onClick={() => setNotice('')}>×</button></div>}

        {showMember ? (
          <section className="content form-page">
            <div className="page-actions">
              <div><span className="eyebrow">MEMBER MANAGEMENT</span><h2>Add New Member</h2><p className="muted">Create a membership profile for your gym.</p></div>
              <button className="secondary-btn" type="button" onClick={() => setShowMember(false)}>Cancel</button>
            </div>
            <div className="panel form-panel">
              <form onSubmit={addMember}>
                <div className="form-grid">
                  <label>Full Name<input required placeholder="Member name" value={memberForm.full_name} onChange={e => setMemberForm({ ...memberForm, full_name: e.target.value })}/></label>
                  <label>Phone Number<input placeholder="Phone number" value={memberForm.phone} onChange={e => setMemberForm({ ...memberForm, phone: e.target.value })}/></label>
                  <label>Email Address<input type="email" placeholder="Email address" value={memberForm.email} onChange={e => setMemberForm({ ...memberForm, email: e.target.value })}/></label>
                  <label>Membership Plan<select value={memberForm.plan_id} onChange={e => setMemberForm({ ...memberForm, plan_id: e.target.value })}><option value="">Select Plan</option>{plans.map(p => <option key={p.id} value={p.id}>{p.name} — {money(p.price)}</option>)}</select></label>
                  <label>Membership Start<input type="date" value={memberForm.membership_start} onChange={e => setMemberForm({ ...memberForm, membership_start: e.target.value })}/></label>
                  <label>Membership End<input type="date" value={memberForm.membership_end} onChange={e => setMemberForm({ ...memberForm, membership_end: e.target.value })}/></label>
                </div>
                <div className="modal-actions"><button type="button" className="secondary-btn" onClick={() => setShowMember(false)}>Cancel</button><button className="primary-btn" type="submit" disabled={busy}><Plus size={16}/>{busy ? 'Saving...' : 'Save Member'}</button></div>
              </form>
            </div>
          </section>
        ) : showPlan ? (
          <section className="content form-page">
            <div className="page-actions">
              <div><span className="eyebrow">MEMBERSHIP MANAGEMENT</span><h2>{editingPlan ? 'Edit Membership Plan' : 'Create Membership Plan'}</h2></div>
              <button className="secondary-btn" onClick={() => setShowPlan(false)}>Cancel</button>
            </div>
            <div className="panel form-panel">
              <form onSubmit={savePlan}>
                <div className="form-grid">
                  <label>Plan Name<input required placeholder="e.g. Monthly Gold" value={planForm.name} onChange={e => setPlanForm({ ...planForm, name: e.target.value })}/></label>
                  <label>Price (₹)<input required min="1" type="number" placeholder="1500" value={planForm.price} onChange={e => setPlanForm({ ...planForm, price: e.target.value })}/></label>
                  <label>Duration (days)<input required min="1" type="number" value={planForm.duration_days} onChange={e => setPlanForm({ ...planForm, duration_days: e.target.value })}/></label>
                </div>
                <div className="modal-actions"><button type="button" className="secondary-btn" onClick={() => setShowPlan(false)}>Cancel</button><button className="primary-btn" type="submit" disabled={busy}>{busy ? 'Saving...' : 'Save Plan'}</button></div>
              </form>
            </div>
          </section>
        ) : (
          <>
            {tab === 'Dashboard' && <section className="content dashboard-content">
              <div className="dashboard-hero">
                <img className="hero-photo" src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1600&q=85" alt="Modern gym interior"/>
                <div className="hero-shade"/>
                <div className="hero-content">
                  <span className="hero-tag"><Sparkles size={14}/> YOUR FITNESS BUSINESS</span>
                  <h2>Welcome back,<br/>{profile?.full_name || 'Gym Owner'}!</h2>
                  <p>Make every workout count. Manage your gym with FlexDesk.</p>
                  <button className="hero-btn" onClick={() => setShowMember(true)}><Plus size={17}/> Add New Member</button>
                </div>
                <div className="hero-dumbbell"><Dumbbell size={82}/></div>
              </div>

              <div className="dashboard-heading">
                <div><span className="eyebrow">YOUR GYM AT A GLANCE</span><h2>Dashboard Overview</h2></div>
                <span className="live-label"><span/> LIVE DATA</span>
              </div>

              <div className="stats-grid premium-stats">
                <Stat icon={Users} label="Total Members" value={members.length} note="All registered members"/>
                <Stat icon={Activity} label="Active Members" value={activeMembers} note="Currently active"/>
                <Stat icon={Wallet} label="Monthly Revenue" value={money(monthlyRevenue)} note="Paid payments this month"/>
                <Stat icon={CalendarCheck} label="Today's Attendance" value={attendance.filter(a => a.status === 'present').length} note="Members present today"/>
              </div>

              <div className="dashboard-grid">
                <div className="panel revenue-panel">
                  <div className="panel-head"><div><span className="eyebrow">FINANCIAL OVERVIEW</span><h3>Revenue Activity</h3><p className="muted">Daily paid revenue · Last 7 days</p></div><div className="chart-icon"><TrendingUp size={20}/></div></div>
                  <div className="chart-total">{money(revenueChart.reduce((s, d) => s + d.amount, 0))}</div>
                  <div className="revenue-chart">
                    {revenueChart.map((d, i) => <div className="chart-column" key={i}>
                      <div className="chart-bar-area"><div className="chart-bar" style={{ height: `${Math.max(7, (d.amount / maxRevenue) * 100)}%` }} title={money(d.amount)}/></div>
                      <span>{d.day}</span>
                    </div>)}
                  </div>
                </div>

                <div className="panel activity-panel">
                  <div className="panel-head"><div><span className="eyebrow">QUICK ACCESS</span><h3>Quick Actions</h3></div><div className="chart-icon"><Sparkles size={19}/></div></div>
                  <button className="action-row" onClick={() => setShowMember(true)}><span className="action-icon"><UserPlus/></span><span><b>Add New Member</b><small>Register a gym member</small></span><ChevronRight/></button>
                  <button className="action-row" onClick={() => setTab('Attendance')}><span className="action-icon"><CalendarCheck/></span><span><b>Mark Attendance</b><small>Manage today's check-in</small></span><ChevronRight/></button>
                  <button className="action-row" onClick={() => setTab('Plans')}><span className="action-icon"><Dumbbell/></span><span><b>Membership Plans</b><small>Manage your packages</small></span><ChevronRight/></button>
                </div>

                <div className="panel recent-panel">
                  <div className="panel-head"><div><span className="eyebrow">MEMBER MANAGEMENT</span><h3>Recent Members</h3><p className="muted">Latest members who joined your gym</p></div><button className="text-btn" onClick={() => setTab('Members')}>View all <ArrowUpRight size={14}/></button></div>
                  <MemberTable rows={members.slice(0, 5)} onDelete={deleteMember}/>
                </div>

                <div className="panel gym-info-panel">
                  <div className="gym-photo">
                    <img src="https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=900&q=85" alt="Gym strength training"/>
                    <div className="gym-photo-overlay"/>
                    <div className="gym-photo-caption"><span>FLEXDESK WORKSPACE</span><h3>{gym?.name || 'Your Gym'}</h3></div>
                  </div>
                  <div className="gym-info-bottom"><div><Users size={17}/><span>{members.length} Total Members</span></div><div><Clock size={17}/><span>{attendance.length} Check-ins Today</span></div></div>
                </div>
              </div>
            </section>}

            {tab === 'Members' && <section className="content">
              <div className="page-actions"><div><span className="eyebrow">MEMBER DIRECTORY</span><h2>Members</h2><p className="muted">Manage your gym's member records.</p></div><button className="primary-btn" onClick={() => setShowMember(true)}><Plus size={17}/> Add Member</button></div>
              <div className="panel"><div className="table-toolbar"><div className="searchbox"><Search size={17}/><input placeholder="Search name or phone..." value={search} onChange={e => setSearch(e.target.value)}/></div><span className="muted">{filteredMembers.length} members</span></div><MemberTable rows={filteredMembers} onDelete={deleteMember}/></div>
            </section>}

            {tab === 'Payments' && <section className="content">
              <div className="page-actions"><div><span className="eyebrow">FINANCE</span><h2>Payments</h2><p className="muted">Payment records for your gym.</p></div></div>
              <div className="stats-grid"><Stat icon={Wallet} label="Total recorded" value={money(payments.filter(p => p.status === 'paid').reduce((s, p) => s + Number(p.amount || 0), 0))} note="All-time paid payments"/><Stat icon={CreditCard} label="This month" value={money(monthlyRevenue)} note="Paid this month"/></div>
              <div className="panel"><h3>Payment History</h3>{payments.length === 0 ? <Empty text="No payments recorded yet. Payment entry can be added in a future update."/> : <div className="table-wrap"><table><thead><tr><th>Date</th><th>Member ID</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead><tbody>{payments.map(p => <tr key={p.id}><td>{p.payment_date || '—'}</td><td>{p.member_id ? `${p.member_id.slice(0, 8)}…` : '—'}</td><td>{money(p.amount)}</td><td>{p.payment_method || '—'}</td><td><span className={`status ${p.status === 'paid' ? 'green' : ''}`}>{p.status || '—'}</span></td></tr>)}</tbody></table></div>}</div>
            </section>}

            {tab === 'Attendance' && <section className="content">
              <div className="page-actions"><div><span className="eyebrow">DAILY CHECK-IN</span><h2>Attendance</h2><p className="muted">Mark members present for {new Date().toLocaleDateString('en-IN')}.</p></div></div>
              <div className="panel"><div className="table-wrap"><table><thead><tr><th>Member</th><th>Phone</th><th>Today</th><th>Action</th></tr></thead><tbody>{members.map(m => { const a = attendance.find(x => x.member_id === m.id); return <tr key={m.id}><td><b>{m.full_name}</b></td><td>{m.phone || '—'}</td><td><span className={`status ${a?.status === 'present' ? 'green' : ''}`}>{a?.status || 'Not marked'}</span></td><td><button className="small-btn" onClick={() => markAttendance(m.id, 'present')}>Present</button> <button className="small-btn ghost" onClick={() => markAttendance(m.id, 'absent')}>Absent</button></td></tr>; })}</tbody></table></div>{members.length === 0 && <Empty text="Add members first to take attendance."/>}</div>
            </section>}

            {tab === 'Plans' && <section className="content">
              <div className="page-actions"><div><span className="eyebrow">MEMBERSHIP MANAGEMENT</span><h2>Membership Plans</h2><p className="muted">Manage your gym membership packages.</p></div><button className="primary-btn" onClick={() => { setEditingPlan(null); setPlanForm({ name: '', price: '', duration_days: '30' }); setShowPlan(true); }}><Plus size={17}/> Add New Plan</button></div>
              <div className="plan-grid premium-plan-grid">
                {plans.length === 0 ? <div className="panel plan-empty"><Empty text="No membership plans yet. Add your first plan."/></div> : plans.map(p => <div className="plan-card premium-plan-card" key={p.id}><div className="plan-card-icon"><Dumbbell size={20}/></div><span className="plan-tag">{p.duration_days} DAYS</span><h3>{p.name}</h3><strong>{money(p.price)}</strong><p className="muted">Membership access</p><div className="plan-actions"><button className="small-btn" onClick={() => { setEditingPlan(p); setPlanForm({ name: p.name, price: String(p.price), duration_days: String(p.duration_days) }); setShowPlan(true); }}><Edit3 size={13}/> Edit</button><button className="small-btn danger-btn" onClick={() => deletePlan(p)}><Trash2 size={13}/> Delete</button></div></div>)}
              </div>
            </section>}
          </>
        )}
        <footer className="mobile-byline">FLEXDESK · MADE WITH CARE BY <b>VANSH</b></footer>
      </main>
    </div>
  );
}

function Stat({ icon: Icon, label, value, note }) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><div className="stat-icon"><Icon size={19}/></div></div><strong>{value}</strong><small>{note}</small></div>;
}

function Empty({ text }) {
  return <div className="empty"><div className="empty-icon"><Activity/></div><p>{text}</p></div>;
}

function MemberTable({ rows, onDelete }) {
  if (!rows.length) return <Empty text="No members yet. Add your first gym member to get started."/>;
  return <div className="table-wrap"><table><thead><tr><th>Member</th><th>Phone</th><th>Joined</th><th>Membership End</th><th>Status</th><th/></tr></thead><tbody>{rows.map(m => <tr key={m.id}><td><div className="member-cell"><div className="member-avatar">{(m.full_name || '?').slice(0, 1).toUpperCase()}</div><b>{m.full_name}</b></div></td><td>{m.phone || '—'}</td><td>{m.join_date || m.created_at?.slice(0, 10) || '—'}</td><td>{m.membership_end || '—'}</td><td><span className={`status ${m.status === 'active' ? 'green' : ''}`}>{m.status || '—'}</span></td><td><button className="delete-btn" onClick={() => onDelete(m.id)}>Delete</button></td></tr>)}</tbody></table></div>;
}

function AuthScreen({ mode, setMode, email, setEmail, password, setPassword, fullName, setFullName, gymName, setGymName, authSubmit, busy, error, notice }) {
  return <div className="auth-shell"><div className="auth-art"><div className="auth-brand"><div className="brand-mark"><Dumbbell/></div><b>FLEXDESK</b></div><div className="auth-copy"><span className="eyebrow">THE GYM OWNER'S WORKSPACE</span><h1>Run your gym.<br/><em>Not the paperwork.</em></h1><p>Members, memberships and daily attendance — organised in one place.</p><div className="auth-feature"><span>✦</span> A clearer view of your gym business</div></div><div className="auth-credit">Made with care <b>by Vansh ✦</b></div></div><div className="auth-form-side"><form className="auth-card" onSubmit={authSubmit}><span className="eyebrow">{mode === 'login' ? 'WELCOME BACK' : 'GET STARTED'}</span><h2>{mode === 'login' ? 'Sign in to FlexDesk' : 'Create your gym account'}</h2><p className="muted">{mode === 'login' ? 'Enter your details to access your workspace.' : 'Start managing your gym with FlexDesk.'}</p>{mode === 'signup' && <><label>Your name<input required value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Full name"/></label><label>Gym name<input required value={gymName} onChange={e => setGymName(e.target.value)} placeholder="e.g. Iron House Fitness"/></label></>}<label>Email address<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input required minLength="6" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters"/></label>{error && <div className="form-error">{error}</div>}{notice && <div className="form-notice">{notice}</div>}<button className="primary-btn full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button><p className="switch-auth">{mode === 'login' ? 'New to FlexDesk?' : 'Already have an account?'} <button type="button" onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}>{mode === 'login' ? 'Create account' : 'Sign in'}</button></p><div className="auth-foot">FLEXDESK <span>•</span> by Vansh</div></form></div></div>;
}

function SetupScreen() {
  return <div className="center-screen"><div className="auth-card"><div className="brand-mark"><Dumbbell/></div><h2>Connect FlexDesk to Supabase</h2><p className="muted">Create a <code>.env</code> file using the included <code>.env.example</code>, then add your Supabase Project URL and publishable key.</p></div></div>;
}
